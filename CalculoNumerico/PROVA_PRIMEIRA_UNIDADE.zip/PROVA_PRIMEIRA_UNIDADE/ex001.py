#Criei um pacote com todas as funções para serem resolvidos os problemas a partes esse import abaixo faz a chamada dele

from Pacote_Algoritmos.algoritmos import biseccao, gauss_seidel, newton, secante
import math

#QUESTÃO 05 da PROVA

g = 9.8
m = 110.0
t = 7.0
v = 40.0

def f(c):
    return ((g * m) / c) * (1 - math.exp(-t * (c / m))) - v

def df(c):
    return -(g * m / (c ** 2)) * (1 - math.exp(-t * (c / m))) + (g * t / c) * math.exp(-t * (c / m))

a = 10.0
b = 20.0

print("Reposta da questão 5")
print(newton(f, df, 15.0, 1e-6))
print(secante(f, a, b, 1e-6))

print("")

#QUESTÃO 06 da Prova

matriz_A = [
    [18.0,  3.0,  2.0,  2.0],
    [ 3.0, 14.0,  2.0,  5.0],
    [ 2.0,  4.0, 16.0,  6.0],
    [ 2.0,  3.0,  6.0, 24.0]  
]

vetor_b = [650.0, 720.0, 750.0, 990.0]

print("Resposta da questao 6")
print(gauss_seidel(matriz_A, vetor_b, 4, 1e-6))
